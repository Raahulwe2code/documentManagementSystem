import connection from "../../Db.js";
import { StatusCodes } from "http-status-codes";

export async function add_clients(req, res) {
  console.log("body" + JSON.stringify(req.body));
  var {
    admin_id,
    type,
    name,
    email,
    phone_no,
    address,
    company_name,
    company_address,
  } = req.body;

  connection.query(
    "insert into clients ( `admin_id`,`type`, `name`, `email`,`phone_no`,`address`,`company_name`,`company_address`) VALUES('" +
      admin_id +
      "','" +
      type +
      "', '" +
      name +
      "', '" +
      email +
      "','" +
      phone_no +
      "', '" +
      address +
      "', '" +
      company_name +
      "', '" +
      company_address +
      "') ",
    (err, rows) => {
      if (err) {
        console.log(err);
        res
          .status(StatusCodes.INTERNAL_SERVER_ERROR)
          .json({ message: "something went wrong" });
      } else {
        res
          .status(StatusCodes.OK)
          .json({ message: "Client added successfully" });
      }
    }
  );
}

export async function update_client(req, res) {
  var {
    id,
    admin_id,
    type,
    name,
    email,
    phone_no,
    address,
    company_name,
    company_address,
  } = req.body;

  connection.query(
    "UPDATE `clients` SET `admin_id`='" +
      admin_id +
      "',`type`='" +
      type +
      "',`name`='" +
      name +
      "',`phone_no`='" +
      phone_no +
      "',`email`='" +
      email +
      "',`address`='" +
      address +
      "',`company_name`='" +
      company_name +
      "',`company_address`='" +
      company_address +
      "' WHERE id='" +
      id +
      "' ",
    (err, rows) => {
      if (err) {
        console.log(err);
        res
          .status(StatusCodes.INTERNAL_SERVER_ERROR)
          .json({ message: "something went wrong" });
      } else {
        res
          .status(StatusCodes.OK)
          .json({ message: "updated Client successfully" });
      }
    }
  );
}
export async function get_all_clients(req, res) {
  let { admin_id } = req.body;
  connection.query(
    "select * from clients where admin_id='" + admin_id + "'",
    (err, rows) => {
      if (err) {
        res
          .status(StatusCodes.INTERNAL_SERVER_ERROR)
          .json({ message: "something went wrong" });
      } else {
        res.status(StatusCodes.OK).json(rows);
      }
    }
  );
}

export async function get_client_by_Id(req, res) {
  var { id } = req.body;
  connection.query(
    "select * from clients where id= '" + id + "'",
    (err, rows) => {
      if (err) {
        res
          .status(StatusCodes.INTERNAL_SERVER_ERROR)
          .json({ message: "something went wrong" });
      } else {
        res.status(StatusCodes.OK).json(rows);
      }
    }
  );
}
